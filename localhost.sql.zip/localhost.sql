-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 30 Janvier 2008 à 00:18
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `ispg`
--
CREATE DATABASE `ispg` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ispg`;

-- --------------------------------------------------------

--
-- Structure de la table `conge`
--

CREATE TABLE IF NOT EXISTS `conge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idEmployer` int(8) NOT NULL,
  `dateAller` varchar(11) NOT NULL,
  `dateRetour` varchar(11) NOT NULL,
  `motif` text NOT NULL,
  `typeconge` text,
  `dateFaite` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `retourne` varchar(5) NOT NULL DEFAULT 'Non',
  PRIMARY KEY (`id`),
  KEY `conge` (`idEmployer`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `conge`
--


-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

CREATE TABLE IF NOT EXISTS `cours` (
  `idCours` int(11) NOT NULL AUTO_INCREMENT,
  `n_cours` varchar(100) NOT NULL,
  `sant_pub` varchar(5) NOT NULL,
  `sage_fem` varchar(5) NOT NULL,
  `dev_com` varchar(5) NOT NULL,
  `s_inf` varchar(5) NOT NULL,
  `annee` varchar(20) NOT NULL DEFAULT '',
  `n_heure` int(3) NOT NULL,
  `credit` int(2) NOT NULL,
  `semestre` varchar(20) DEFAULT NULL,
  `date_fixed` varchar(15) NOT NULL,
  `commentaire` text,
  PRIMARY KEY (`idCours`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `cours`
--

INSERT INTO `cours` (`idCours`, `n_cours`, `sant_pub`, `sage_fem`, `dev_com`, `s_inf`, `annee`, `n_heure`, `credit`, `semestre`, `date_fixed`, `commentaire`) VALUES
(1, 'INGENIERIE', 'true', 'false', 'false', 'false', 'BAC I', 60, 4, '2', '2019-05-24', ''),
(2, 'TECHNIQUE', 'true', 'false', 'false', 'false', 'BAC III', 75, 5, '2', '2019-05-25', ''),
(3, 'SANTE PUBLIC', 'true', 'false', 'false', 'false', 'BAC I', 60, 4, '2', '2019-05-25', ''),
(4, 'ELECTRO BASE', 'true', 'false', 'false', 'false', 'BAC II', 45, 3, '1', '2019-05-25', ''),
(5, 'GHDDJ', 'true', 'false', 'false', 'false', 'BAC III', 45, 15, '1', '2019-06-03', ''),
(6, 'SAGE FEMME', 'false', 'true', 'false', 'false', 'BAC I', 60, 15, '1', '2019-06-04', ''),
(7, 'SOINS INFIRMIER', 'false', 'false', 'false', 'true', 'BAC I', 45, 2, '1', '2019-06-07', ''),
(8, 'DEVELOPPEMENT COMMUNAUTAIRE', 'false', 'false', 'true', 'false', 'BAC II', 60, 4, '1', '2019-06-07', '');

-- --------------------------------------------------------

--
-- Structure de la table `emplfiche`
--

CREATE TABLE IF NOT EXISTS `emplfiche` (
  `idEmployer` int(11) NOT NULL,
  `idposte` int(11) NOT NULL,
  KEY `emplfiche` (`idEmployer`),
  KEY `emlpfiche` (`idposte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `emplfiche`
--


-- --------------------------------------------------------

--
-- Structure de la table `enseignant`
--

CREATE TABLE IF NOT EXISTS `enseignant` (
  `n_matricule` varchar(30) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `type_enseignant` varchar(30) NOT NULL,
  UNIQUE KEY `n_matricule` (`n_matricule`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `enseignant`
--


-- --------------------------------------------------------

--
-- Structure de la table `enseignant_cours`
--

CREATE TABLE IF NOT EXISTS `enseignant_cours` (
  `idEnregistrement` int(11) NOT NULL AUTO_INCREMENT,
  `idCours` varchar(11) NOT NULL,
  `idProf` int(11) NOT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idEnregistrement`),
  UNIQUE KEY `idCours` (`idCours`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `enseignant_cours`
--


-- --------------------------------------------------------

--
-- Structure de la table `fiche_salaire`
--

CREATE TABLE IF NOT EXISTS `fiche_salaire` (
  `idFiche` int(11) NOT NULL AUTO_INCREMENT,
  `idEmployer` int(11) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `salBase` int(11) NOT NULL,
  `indm_log` int(11) NOT NULL,
  `indm_depl` int(11) NOT NULL,
  `alloc_fam` int(11) NOT NULL,
  `indam_grade` int(11) NOT NULL,
  `prime` int(11) NOT NULL,
  `sal_brut` int(11) DEFAULT NULL,
  `insspers` int(11) NOT NULL,
  `insspatr` int(11) NOT NULL,
  `inssrisquepro` int(11) NOT NULL,
  `mutualiteperso` int(11) NOT NULL,
  `mutualitepatro` int(11) NOT NULL,
  `pensCompl` int(11) NOT NULL,
  `sal_impos` int(11) NOT NULL,
  `ire` int(11) NOT NULL,
  `avanc_sal` float NOT NULL,
  `retSurSal` int(11) NOT NULL,
  `netpayable` int(11) NOT NULL,
  `netApay` int(11) NOT NULL,
  `dateEnr` varchar(40) NOT NULL,
  `commentaire` text,
  PRIMARY KEY (`idFiche`),
  UNIQUE KEY `idPoste` (`idEmployer`),
  UNIQUE KEY `idEmployer` (`idEmployer`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `fiche_salaire`
--

INSERT INTO `fiche_salaire` (`idFiche`, `idEmployer`, `qualification`, `salBase`, `indm_log`, `indm_depl`, `alloc_fam`, `indam_grade`, `prime`, `sal_brut`, `insspers`, `insspatr`, `inssrisquepro`, `mutualiteperso`, `mutualitepatro`, `pensCompl`, `sal_impos`, `ire`, `avanc_sal`, `retSurSal`, `netpayable`, `netApay`, `dateEnr`, `commentaire`) VALUES
(2, 1, 'dr', 445665, 267399, 66849, 0, 4554, 6555, 791022, 18000, 27000, 2400, 20944, 31417, 4556, 413274, 42982, 55555, 5566, 704540, 643419, 'samedi 13 juillet 2019 23:53:38', 'ajouter aux favoris'),
(6, 2, 'PDH', 2000000, 1200000, 300000, 0, 50000, 60000, 3610000, 18000, 27000, 2400, 144600, 96400, 30000, 1965600, 529680, 0, 20000, 2935920, 2915920, 'samedi 27 juillet 2019 12:03:40', ''),
(5, 4, 'maitre', 1000000, 600000, 150000, 15000, 50000, 20000, 1820000, 18000, 27000, 2400, 72300, 48200, 89566, 914234, 214270, 5000, 5000, 1449964, 1439964, 'samedi 27 juillet 2019 11:53:23', '');

-- --------------------------------------------------------

--
-- Structure de la table `hist_paiement`
--

CREATE TABLE IF NOT EXISTS `hist_paiement` (
  `idEmpl` int(11) NOT NULL,
  `salTot` int(8) NOT NULL,
  `frInss` int(8) NOT NULL,
  `frMut` int(8) NOT NULL,
  `pensCompl` int(8) NOT NULL,
  `impot` int(8) NOT NULL,
  `salPay` int(8) NOT NULL,
  `date_payer` varchar(40) NOT NULL DEFAULT '',
  `commentaire` text NOT NULL,
  KEY `hist_paiement` (`idEmpl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `hist_paiement`
--


-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE IF NOT EXISTS `paiement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idEmpl` int(11) NOT NULL,
  `salTot` int(8) NOT NULL,
  `frInss` int(8) NOT NULL,
  `frMut` int(8) NOT NULL,
  `pensCompl` int(8) NOT NULL,
  `impot` int(8) NOT NULL,
  `salPay` int(8) NOT NULL,
  `date_payer` varchar(40) NOT NULL DEFAULT '',
  `commentaire` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idEmpl` (`idEmpl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `paiement`
--


-- --------------------------------------------------------

--
-- Structure de la table `personel`
--

CREATE TABLE IF NOT EXISTS `personel` (
  `idEmployer` int(11) NOT NULL AUTO_INCREMENT,
  `n_matricule` varchar(30) NOT NULL DEFAULT '',
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `sexe` varchar(15) NOT NULL,
  `date_naissance` varchar(20) NOT NULL,
  `nationalite` varchar(30) NOT NULL,
  `col_naissance` varchar(40) NOT NULL DEFAULT '',
  `zone` varchar(40) NOT NULL DEFAULT '',
  `commune` varchar(40) NOT NULL,
  `province` varchar(100) NOT NULL,
  `banque` varchar(40) NOT NULL DEFAULT '',
  `n_compte` varchar(60) NOT NULL,
  `enseignant` varchar(5) NOT NULL,
  `direction` varchar(5) NOT NULL DEFAULT '',
  `travailleur` varchar(5) NOT NULL,
  `poste` text NOT NULL,
  `typecontrat` text,
  `date_embaucher` varchar(30) NOT NULL,
  PRIMARY KEY (`idEmployer`,`n_matricule`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `personel`
--

INSERT INTO `personel` (`idEmployer`, `n_matricule`, `nom`, `prenom`, `sexe`, `date_naissance`, `nationalite`, `col_naissance`, `zone`, `commune`, `province`, `banque`, `n_compte`, `enseignant`, `direction`, `travailleur`, `poste`, `typecontrat`, `date_embaucher`) VALUES
(1, '455674', 'Ndayisenga', 'mathieu', 'Homme', '30-07-2018', 'burundaise', 'kigoma', 'marangara', 'marangara', 'Ngozi', 'KCB', '744/536', 'false', 'false', 'true', 'daf', 'jdhd', '01-07-2019'),
(2, '856555', 'Muhimpundu', 'Annick', 'Femme', '18-10-0026', 'Burundaise', 'kamnx', 'jskak', 'lsjsjn', 'Ngzi', 'dmana', '65455', 'false', 'false', 'true', 'Hdk', 'idet', '01-07-2019'),
(4, '565/45', 'ndayishimiye', 'Adelphine', 'Femme', '12-07-2014', 'Burundaise', 'kagoma', 'kagoma', 'Rumonge', 'Rumonge', 'bancobu', '694369', 'true', 'false', 'false', 'idk', 'annuel', '03-07-2019'),
(5, '4556', 'ndayizeye', 'jean', 'Homme', '06-07-2018', 'burundaise', 'Jimkana', 'Jumkana', 'gitega', 'gitega', 'bancobu', '45614455', 'false', 'true', 'false', 'V_K', 'annuel', '03-07-2019');

-- --------------------------------------------------------

--
-- Structure de la table `presence`
--

CREATE TABLE IF NOT EXISTS `presence` (
  `idEmployer` int(11) NOT NULL,
  `heurArriver` text NOT NULL,
  `heurDep` text,
  `commentaire` text,
  KEY `presence` (`idEmployer`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `presence`
--


-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `pswd` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pswd` (`pswd`),
  UNIQUE KEY `pswd_2` (`pswd`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `pswd`) VALUES
(2, 'nimubonajean', '123456');
